<?php 
echo "<p> Erreur dans l'action. </p>";
require(File::build_path(array("view", "voiture", "list.php")));
?>