<?php  
echo 'Cette immatriculation appartien déjà au registre. ';
require(File::build_path(array("view", "voiture", "list.php")));
?>