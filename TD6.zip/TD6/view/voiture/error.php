<?php 
echo "Pas de voiture correspondante. ";
?>